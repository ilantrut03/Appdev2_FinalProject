package com.example.project;

public interface ListenerInterface {
    void onItemClick(int position);
}
